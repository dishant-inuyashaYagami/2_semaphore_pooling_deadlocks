setenv NUM_ROOTS   4
setenv GRAPH_DEPTH 10
make

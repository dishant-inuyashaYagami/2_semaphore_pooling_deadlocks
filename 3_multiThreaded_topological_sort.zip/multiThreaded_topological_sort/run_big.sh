setenv NUM_ROOTS   100
setenv GRAPH_DEPTH 20000    # the stack space is limited  # if you set it higher; it will probably give segmentation fault
make

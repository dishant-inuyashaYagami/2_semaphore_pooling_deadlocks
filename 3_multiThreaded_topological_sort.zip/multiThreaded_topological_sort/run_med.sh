setenv NUM_ROOTS   9
setenv GRAPH_DEPTH 100
make
